#include <string>

// char direction(const char c);
std::string longDirection(const char c);